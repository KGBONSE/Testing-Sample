package dk.danskespil.psp.pages;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OmPage {
	public OmPage(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
		WebDriverWait wait = new WebDriverWait(driver, 40);
		wait.until(ExpectedConditions.titleContains("Velkommen"));
	}
	
	WebDriver driver;

	public void AssertPageTitle(String titleText){
		assertTrue("Om os page title not found!", driver.getTitle().toLowerCase().contains(titleText.toLowerCase()));
	}
}
