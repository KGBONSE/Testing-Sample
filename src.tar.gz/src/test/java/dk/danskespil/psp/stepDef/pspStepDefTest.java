package dk.danskespil.psp.stepDef;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.NoSuchFileException;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import dk.danskespil.psp.pages.HomePage;
import dk.danskespil.psp.pages.OmPage;

public class pspStepDefTest {

	public pspStepDefTest() {

		super();
	}

	WebDriver driver;
	public static final String USERNAME = "danskespil2";
	public static final String AUTOMATE_KEY = "RiuiwqAeV8qV64yVZD2x";
	public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
	public static final String BASE_URL = "https://danskespil.dk/vinder";

	private HomePage homePage;
	private OmPage omPage;
	private ResourceLoader rl;

	@Before
	public void prepare() throws MalformedURLException {
		rl = new ResourceLoader("application.properties");
		InputStream is;
		String resourceFileContent;
		try {
			is = rl.getResource();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			resourceFileContent = reader.lines().collect(Collectors.joining("\n"));
			if (resourceFileContent.contains("local")) {
				RunLocally(BASE_URL);
			} else {
				RunInBrowserStack(BASE_URL);
			}
		} catch (NoSuchFileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void RunLocally(String baseUrl) throws MalformedURLException {
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("disable-infobars");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		capabilities.setCapability("browser", "chrome");
		capabilities.setCapability("browser_version", "62.0");
		capabilities.setCapability("os", "Windows");
		capabilities.setCapability("os_version", "10");
		capabilities.setCapability("resolution", "1024x768");
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities);
		driver.get(baseUrl);
	}

	public void RunInBrowserStack(String baseUrl) throws MalformedURLException {
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("disable-infobars");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		capabilities.setCapability("browser", "chrome");
		capabilities.setCapability("browser_version", "62.0");
		capabilities.setCapability("os", "Windows");
		capabilities.setCapability("os_version", "10");
		capabilities.setCapability("resolution", "1024x768");
		capabilities.setCapability("browserstack.local", "true");
		capabilities.setCapability("project", "EBU-PSP");
		capabilities.setCapability("build", "Local");
		driver = new RemoteWebDriver(new URL(URL), capabilities);
		driver.get(baseUrl);
	}

	@After
	public void cleanUp() {
		driver.close();
	}

	@Given("^I visit the EBU landing page$")
	public void i_visit_the_EBU_landing_page() throws Throwable {
		homePage = PageFactory.initElements(driver, HomePage.class);
	}

	@When("^I click on the om os link$")
	public void i_click_on_the_om_os_link() throws Throwable {
		homePage.navigateToOmPage();
	}

	@Then("^the page title contains \"([^\"]*)\"$")
	public void then_the_page_title_contains(String titleText) throws Throwable {
		omPage = PageFactory.initElements(driver, OmPage.class);
		omPage.AssertPageTitle(titleText);
	};

}
