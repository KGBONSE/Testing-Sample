package dk.danskespil.psp.runAllTest;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions(format = {"pretty", "json:target/cucumber.json"},
        glue = ("dk.danskespil.psp.stepDef"),
        features="src/test/resources/features/",
        tags ="@test")
public class RunCukeTest {
}

